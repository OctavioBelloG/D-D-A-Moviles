import 'package:flutter/material.dart';

class AppBarWidget extends StatelessWidget {
  const AppBarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text("Mapaches"),
      centerTitle: true,
      backgroundColor: Colors.green,
      foregroundColor: Colors.white,
      actions: [
        IconButton(icon: Icon(Icons.search), onPressed: () {}),
        IconButton(icon: Icon(Icons.add), onPressed: () {}),
        IconButton(icon: Icon(Icons.favorite), onPressed: () {}),
      ],
    );
  }
}
